<?php
/*
Plugin Name: Propagan Banner
Description: Um plugin completo para exibir banners responsivos com seletor de imagens do WordPress.
Version: 2.1
Author: Seu Nome
*/

// Enfileirar scripts e estilos
function propagan_banner_assets() {
    // CSS front-end
    wp_enqueue_style('propagan-banner-style', plugins_url('css/propagan-banner.css', __FILE__));
    
    // JS front-end
    wp_enqueue_script('propagan-banner-script', plugins_url('js/propagan-banner.js', __FILE__), array('jquery'), '1.0', true);
    
    // Media uploader (admin)
    if (is_admin()) {
        wp_enqueue_media();
        wp_enqueue_style('propagan-banner-admin', plugins_url('css/admin.css', __FILE__));
        wp_enqueue_script('propagan-banner-admin', plugins_url('js/admin.js', __FILE__), array('jquery'), '1.0', true);
    }
}
add_action('wp_enqueue_scripts', 'propagan_banner_assets');
add_action('admin_enqueue_scripts', 'propagan_banner_assets');

// Shortcode para exibir os banners
function propagan_banner_shortcode($atts) {
    $atts = shortcode_atts(array(
        'device' => 'desktop',
    ), $atts, 'propagan_banner');

    $banner_data = array();
    for ($i = 1; $i <= 4; $i++) {
        $image_url = get_option("propagan_banner_{$atts['device']}_image{$i}_url", '');
        $banner_link = get_option("propagan_banner_{$atts['device']}_link{$i}", '');
        
        if (!empty($image_url)) {
            $banner_data[] = array(
                'image_url' => $image_url,
                'link' => $banner_link
            );
        }
    }

    if (empty($banner_data)) {
        return '<div class="propagan-banner-notice">Nenhum banner configurado para este dispositivo.</div>';
    }

    ob_start(); ?>
    <div class="propagan-banner-slider">
        <div class="propagan-slider-container">
            <?php foreach ($banner_data as $index => $banner): ?>
                <div class="propagan-slide">
                    <?php if (!empty($banner['link'])): ?>
                        <a href="<?php echo esc_url($banner['link']); ?>" target="_blank" rel="noopener noreferrer">
                    <?php endif; ?>
                    
                    <img src="<?php echo esc_url($banner['image_url']); ?>" 
                         alt="Banner <?php echo ($index + 1); ?>" 
                         class="propagan-banner-img">
                    
                    <?php if (!empty($banner['link'])): ?>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (count($banner_data) > 1): ?>
            <div class="propagan-slider-dots">
                <?php foreach ($banner_data as $index => $banner): ?>
                    <button class="propagan-dot <?php echo $index === 0 ? 'active' : ''; ?>" 
                            data-slide="<?php echo $index; ?>"
                            aria-label="<?php printf(__('Ir para o slide %d', 'propagan-banner'), $index + 1); ?>">
                    </button>
                <?php endforeach; ?>
            </div>
            
            <div class="propagan-slider-arrows">
                <button class="propagan-arrow propagan-prev" aria-label="<?php _e('Slide anterior', 'propagan-banner'); ?>">
                    ‹
                </button>
                <button class="propagan-arrow propagan-next" aria-label="<?php _e('Próximo slide', 'propagan-banner'); ?>">
                    ›
                </button>
            </div>
        <?php endif; ?>
    </div>
    <?php
    
    return ob_get_clean();
}
add_shortcode('propagan_banner', 'propagan_banner_shortcode');

// Adicionar página de administração
function propagan_banner_menu() {
    add_menu_page(
        'Propagan Banner',
        'Propagan Banner',
        'manage_options',
        'propagan-banner',
        'propagan_banner_settings_page',
        'dashicons-slides',
        100
    );
}
add_action('admin_menu', 'propagan_banner_menu');

// Página de configurações
function propagan_banner_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['propagan_banner_nonce']) && wp_verify_nonce($_POST['propagan_banner_nonce'], 'propagan_banner_save')) {
        $devices = array('desktop', 'tablet', 'mobile');
        foreach ($devices as $device) {
            for ($i = 1; $i <= 4; $i++) {
                $image_id_key = "propagan_banner_{$device}_image{$i}_id";
                $image_url_key = "propagan_banner_{$device}_image{$i}_url";
                $link_key = "propagan_banner_{$device}_link{$i}";
                
                if (isset($_POST[$image_id_key])) {
                    update_option($image_id_key, absint($_POST[$image_id_key]));
                }
                
                if (isset($_POST[$image_url_key])) {
                    update_option($image_url_key, esc_url_raw($_POST[$image_url_key]));
                }
                
                if (isset($_POST[$link_key])) {
                    update_option($link_key, esc_url_raw($_POST[$link_key]));
                }
            }
        }
        
        echo '<div class="notice notice-success"><p>Configurações salvas com sucesso!</p></div>';
    }

    $current_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'desktop';
    $devices = array(
        'desktop' => __('Desktop', 'propagan-banner'),
        'tablet' => __('Tablet', 'propagan-banner'),
        'mobile' => __('Mobile', 'propagan-banner')
    );
    
    ?>
    <div class="wrap propagan-banner-settings">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <h2 class="nav-tab-wrapper">
            <?php foreach ($devices as $tab => $name): ?>
                <a href="?page=propagan-banner&tab=<?php echo $tab; ?>" 
                   class="nav-tab <?php echo $current_tab === $tab ? 'nav-tab-active' : ''; ?>">
                    <?php echo $name; ?>
                </a>
            <?php endforeach; ?>
        </h2>
        
        <form method="post" action="">
            <?php wp_nonce_field('propagan_banner_save', 'propagan_banner_nonce'); ?>
            
            <div class="propagan-banner-grid">
                <?php for ($i = 1; $i <= 4; $i++): ?>
                    <div class="propagan-banner-item">
                        <h3><?php printf(__('Banner %d', 'propagan-banner'), $i); ?></h3>
                        
                        <div class="propagan-image-uploader">
                            <div class="propagan-image-preview" style="<?php echo get_option("propagan_banner_{$current_tab}_image{$i}_url") ? '' : 'display:none;'; ?>">
                                <img src="<?php echo esc_url(get_option("propagan_banner_{$current_tab}_image{$i}_url")); ?>" alt="<?php _e('Pré-visualização', 'propagan-banner'); ?>">
                                <button type="button" class="propagan-remove-image button">
                                    <?php _e('Remover', 'propagan-banner'); ?>
                                </button>
                            </div>
                            
                            <input type="hidden" 
                                   name="propagan_banner_<?php echo $current_tab; ?>_image<?php echo $i; ?>_id" 
                                   value="<?php echo esc_attr(get_option("propagan_banner_{$current_tab}_image{$i}_id")); ?>">
                                   
                            <input type="hidden" 
                                   name="propagan_banner_<?php echo $current_tab; ?>_image<?php echo $i; ?>_url" 
                                   value="<?php echo esc_url(get_option("propagan_banner_{$current_tab}_image{$i}_url")); ?>">
                                   
                            <button type="button" class="propagan-upload-image button" 
                                    style="<?php echo get_option("propagan_banner_{$current_tab}_image{$i}_url") ? 'display:none;' : ''; ?>">
                                <?php _e('Selecionar Imagem', 'propagan-banner'); ?>
                            </button>
                        </div>
                        
                        <div class="propagan-link-field">
                            <label for="propagan_banner_<?php echo $current_tab; ?>_link<?php echo $i; ?>">
                                <?php _e('Link:', 'propagan-banner'); ?>
                            </label>
                            <input type="url" 
                                   id="propagan_banner_<?php echo $current_tab; ?>_link<?php echo $i; ?>" 
                                   name="propagan_banner_<?php echo $current_tab; ?>_link<?php echo $i; ?>" 
                                   value="<?php echo esc_url(get_option("propagan_banner_{$current_tab}_link{$i}")); ?>" 
                                   placeholder="https://">
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
            
            <?php submit_button(__('Salvar Configurações', 'propagan-banner')); ?>
        </form>
    </div>
    <?php
}
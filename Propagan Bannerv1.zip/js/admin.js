jQuery(document).ready(function($) {
    // Upload de imagem
    $('.propagan-upload-image').on('click', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const $uploader = $button.closest('.propagan-image-uploader');
        const $preview = $uploader.find('.propagan-image-preview');
        const $imageId = $uploader.find('input[type="hidden"]').first();
        const $imageUrl = $uploader.find('input[type="hidden"]').last();
        
        const frame = wp.media({
            title: 'Selecionar Imagem',
            button: {
                text: 'Usar esta imagem'
            },
            multiple: false
        });
        
        frame.on('select', function() {
            const attachment = frame.state().get('selection').first().toJSON();
            
            $preview.find('img').attr('src', attachment.url);
            $preview.show();
            $button.hide();
            
            $imageId.val(attachment.id);
            $imageUrl.val(attachment.url);
        });
        
        frame.open();
    });
    
    // Remover imagem
    $('.propagan-remove-image').on('click', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const $uploader = $button.closest('.propagan-image-uploader');
        const $preview = $uploader.find('.propagan-image-preview');
        const $uploadButton = $uploader.find('.propagan-upload-image');
        const $imageId = $uploader.find('input[type="hidden"]').first();
        const $imageUrl = $uploader.find('input[type="hidden"]').last();
        
        $preview.hide();
        $uploadButton.show();
        
        $imageId.val('');
        $imageUrl.val('');
    });
});
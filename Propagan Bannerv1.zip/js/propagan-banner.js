jQuery(document).ready(function($) {
    $('.propagan-banner-slider').each(function() {
        const $slider = $(this);
        const $container = $slider.find('.propagan-slider-container');
        const $slides = $slider.find('.propagan-slide');
        const $dots = $slider.find('.propagan-dot');
        
        if ($slides.length <= 1) {
            $slider.find('.propagan-slider-dots, .propagan-slider-arrows').hide();
            return;
        }
        
        let currentIndex = 0;
        const slideCount = $slides.length;
        
        function goToSlide(index) {
            currentIndex = (index + slideCount) % slideCount;
            $container.css('transform', `translateX(-${currentIndex * 100}%)`);
            $dots.removeClass('active').eq(currentIndex).addClass('active');
        }
        
        $dots.on('click', function() {
            goToSlide($(this).data('slide'));
        });
        
        $slider.on('click', '.propagan-prev', function() {
            goToSlide(currentIndex - 1);
        });
        
        $slider.on('click', '.propagan-next', function() {
            goToSlide(currentIndex + 1);
        });
        
        // Auto-rotate
        let interval = setInterval(() => goToSlide(currentIndex + 1), 5000);
        $slider.hover(
            () => clearInterval(interval),
            () => interval = setInterval(() => goToSlide(currentIndex + 1), 5000)
        );
    });
});
jQuery(document).ready(function($) {
    $('.propagan-banner-slider').each(function() {
        const $slider = $(this);
        const $container = $slider.find('.propagan-slider-container');
        const $slides = $slider.find('.propagan-slide');
        const $dots = $slider.find('.propagan-dot');
        const $prev = $slider.find('.propagan-prev');
        const $next = $slider.find('.propagan-next');
        
        if ($slides.length <= 1) {
            $slider.find('.propagan-slider-dots, .propagan-slider-arrows').hide();
            return;
        }
        
        let currentIndex = 0;
        const slideCount = $slides.length;
        
        function goToSlide(index) {
            if (index < 0) index = slideCount - 1;
            if (index >= slideCount) index = 0;
            
            currentIndex = index;
            $container.css('transform', `translateX(-${currentIndex * 100}%)`);
            
            $dots.removeClass('active').eq(index).addClass('active');
        }
        
        $dots.on('click', function() {
            const slideIndex = $(this).data('slide');
            goToSlide(slideIndex);
        });
        
        $prev.on('click', function() {
            goToSlide(currentIndex - 1);
        });
        
        $next.on('click', function() {
            goToSlide(currentIndex + 1);
        });
        
        // Auto-rotate if more than 1 slide
        if (slideCount > 1) {
            let interval = setInterval(() => {
                goToSlide(currentIndex + 1);
            }, 5000);
            
            $slider.hover(
                () => clearInterval(interval),
                () => interval = setInterval(() => {
                    goToSlide(currentIndex + 1);
                }, 5000)
            );
        }
    });
});